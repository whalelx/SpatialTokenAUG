from openai import OpenAI
import os
import base64
import jsonlines


sys_prompt = """##角色:视觉空间推理专家
##任务:
- 根据给出的图片、与空间推理相关的问题及回答，从图片中挖掘与给定空间推理问答相关的其他目标。
- 图片中与问题相关的目标被逐一用浅蓝色的框框出，并在每个框的左上角打上了数字标号。
- 请用"是"或者"否"回答问题，若回答为"是"，请逐一列出与问答相关的所有其他目标。

# 输出示例：(必须为json格式)
{
    "exist": "与问答相关的其他目标是否存在"
    "sceneDesc":"与问答相关的其他目标",
}
"""


 
# Function to encode the image
def encode_image(image_path):
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode('utf-8')
 

def run_single_image_idealab(question, image_path):
    base64_image = encode_image(image_path)
    client = OpenAI()
     
    messages=[
        {
            "role": "system", 
             "content": sys_prompt,
        },
        {
            "role": "user", 
             "content": [
                {"type":"text", "text": question},
                {
                   "type":"image_url",
                   "image_url":{
                      "url":f"data:image/png;base64,{base64_image}",
                      }
                }
            ]
        }
    ]
    completion = client.chat.completions.create(
          model="gpt-4o-0513-global",
          messages=messages
    )
    chat_response = completion
    answer = chat_response.choices[0].message.content
    return answer




if __name__ == "__main__":
    question = """{'标准答案': '一只黑色带有橙色斑点的猫坐在地板上，面向一个自动喂食器。猫的位置靠近画面中央偏左，正在观察或等待喂食器的动作。背景中可以看到一些家具和杂物。', '预测答案': '一只白色带有橙色斑点的猫站在猫架上，面向一个自动喂食器。背景中可以看到一些家具和杂物，但没有其他标签库中的实体出现。"'}"""
    answer = run_single_image_idealab(question, "000000083033.jpg")
    print(answer)



