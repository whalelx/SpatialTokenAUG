export OPENAI_BASE_URL=https://idealab.alibaba-inc.com/api/openai/v1
export OPENAI_API_KEY=44bbf2fc47ba022d828d67922aa852d8

# python run_idealab.py
python gx.py
