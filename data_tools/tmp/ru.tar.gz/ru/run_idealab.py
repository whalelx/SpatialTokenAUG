from openai import OpenAI
import os
import base64
import jsonlines

system_prompt = """##角色:视觉空间推理专家
##任务:
- 根据给出的图片、与空间推理相关的问题及回答，从图片中挖掘与给定空间推理问答相关的其他目标。
- 图片中与问题相关的目标被逐一用浅蓝色的框框出，并在每个框的左上角打上了数字标号。
- 请用"是"或者"否"回答问题，若回答为"是"，请逐一列出与问答相关的所有其他目标。

# 输出示例：(必须为json格式)
{
    "exist": "与问答相关的其他目标是否存在"
    "sceneDesc":"与问答相关的其他目标",
}
"""



 
# Function to encode the image
def encode_image(image_path):
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode('utf-8')
 


def run():
    fig_path = '../IPCvideo_image2'
    tag = "long2"
    result_save_path = "gpt4o_long2.json"
    question = system_prompt_llm[tag]


    client = OpenAI()
     
    for taskname in sorted(os.listdir(fig_path)):
        print(taskname)
        image_path=os.path.join(fig_path, taskname)
        base64_image = [encode_image(os.path.join(image_path, str(i)+".png")) for i in range(4)]
           
        messages=[
            {
                "role": "system",
                "content"
            }
            {
                "role": "user", 
                 "content": [
                    {"type":"text", "text": question},
                    {
                       "type":"image_url",
                       "image_url":{
                          "url":f"data:image/png;base64,{base64_image[0]}",
                          "url":f"data:image/png;base64,{base64_image[1]}",
                          "url":f"data:image/png;base64,{base64_image[2]}",
                          "url":f"data:image/png;base64,{base64_image[3]}"
                          }
                    }
                ]
            }
        ]
        completion = client.chat.completions.create(
              model="gpt-4o-0513-global",
              messages=messages
        )
        chat_response = completion
        answer = chat_response.choices[0].message.content

        with jsonlines.open(result_save_path, 'a') as f:
            f.write({"file_name": taskname, "question": question, "output": answer})


if __name__ == "__main__":
    run()

